## THIS STEP IS ONLY FOR LINUX AND MAC SUPPORTED DEVICES  
## FOR WINDOWS DOWNLOAD PYTHON 3 FROM `https://www.python.org/downloads/`  
Before You Start Mining Run This Command To Install Repositeries:  
`python3 -m pip install -r requirements.txt`  
  
Once You Have Installed All Repos Then Run This Command:  
`python3 siricoinminer.py`  
  
## Note that the python version should be atleast 3.9 if its older it wont work  
And You Are Now Promted To Put Your SiriCoin Address Copy and Paste It Then Hit Enter And Your PC is Now Mining.  
  
- Red Eye.
